#include <iostream>
using namespace std;
//check balance, deposit, withdraw, show menu


void Menu() {
	cout << "*******Menu*******" << endl;
	cout << "1. Check Balance" << endl;
	cout << "2. Deposit" << endl;
	cout << "3. Withdraw" << endl;
	cout << "4. Money Transfer" << endl;
	cout << "5. Exit" << endl;
	cout << "******************" << endl;


}


int main()
{
	//varibles
	int option;
	double balance = 500;


	do {

		Menu();
		cout << "Option: ";
		cin >> option;
		system("cls");

		switch (option) {

		case 1: cout << "Balance is: $" << balance << endl; break;
		case 2: cout << "Deposit amount: ";
			double deposit;
			cin >> deposit;
			balance += deposit;
			break;
		case 3: cout << "Withdraw amount: ";
			double withdraw;
			cin >> withdraw;
			if (withdraw <= balance)
				balance -= withdraw;
			else
				cout << "Insufficient Funds ." << endl;
			break;
		case 4: cout << "Money Transfer: ";
			double transfer;
			cin >> transfer;

			if (transfer <= balance)
				balance -= transfer;
			cout << "Money has been transfered." << endl;
			break;
		}
	} while (option != 5);
	cout << "Please remove your card." << endl;
	cout << "Bye." << endl;
	system("pause>0");
}